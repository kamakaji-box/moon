package jp.kamakaji.luna.widget;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.RadialGradient;

/** Renders a quiet, transparent-background moon bitmap for the home-screen widget. */
final class MoonRenderer {
    private static final int SOURCE_ID = jp.kamakaji.luna.widget.R.drawable.lroc_color_2k;

    private MoonRenderer() {
    }

    static Bitmap render(Context context, int size) {
        Bitmap result = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);
        float center = size / 2f;
        float radius = center - 2f;
        RectF disk = new RectF(center - radius, center - radius, center + radius, center + radius);

        Bitmap source = BitmapFactory.decodeResource(context.getResources(), SOURCE_ID);
        if (source == null) {
            return result;
        }

        Paint texture = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
        Rect sourceRect = new Rect(
                source.getWidth() / 4,
                0,
                source.getWidth() * 3 / 4,
                source.getHeight());
        canvas.save();
        Path circleClip = new Path();
        circleClip.addOval(disk, Path.Direction.CW);
        canvas.clipPath(circleClip);
        canvas.drawBitmap(source, sourceRect, new RectF(0, 0, size, size), texture);

        Paint shade = new Paint(Paint.ANTI_ALIAS_FLAG);
        shade.setShader(new RadialGradient(
                center * 0.78f,
                center * 0.72f,
                radius * 1.35f,
                new int[]{Color.TRANSPARENT, Color.argb(32, 0, 0, 0), Color.argb(116, 0, 0, 0)},
                new float[]{0f, 0.70f, 1f},
                Shader.TileMode.CLAMP));
        canvas.drawOval(disk, shade);
        canvas.restore();

        double age = LunarPhase.age(System.currentTimeMillis());
        drawPhaseShadow(canvas, disk, age);
        drawRim(canvas, center, radius, age);

        source.recycle();
        return result;
    }

    private static void drawPhaseShadow(Canvas canvas, RectF disk, double age) {
        double progress = age / LunarPhase.SYNODIC_MONTH;
        boolean waxing = progress < 0.5;
        int samples = 160;
        float center = disk.centerX();
        float radius = disk.width() / 2f;
        double phaseAngle = waxing
                ? Math.PI - progress * 2.0 * Math.PI
                : (progress - 0.5) * 2.0 * Math.PI;
        float outerSide = waxing ? -1f : 1f;
        Path shadow = new Path();

        for (int i = 0; i <= samples; i += 1) {
            double y = -1.0 + (2.0 * i) / samples;
            double edge = Math.sqrt(Math.max(0.0, 1.0 - y * y));
            float x = outerSide * (float) edge;
            if (i == 0) {
                shadow.moveTo(center + x * radius, center + (float) y * radius);
            } else {
                shadow.lineTo(center + x * radius, center + (float) y * radius);
            }
        }

        for (int i = samples; i >= 0; i -= 1) {
            double y = -1.0 + (2.0 * i) / samples;
            double edge = Math.sqrt(Math.max(0.0, 1.0 - y * y));
            double terminatorX = waxing
                    ? -Math.cos(phaseAngle) * edge
                    : Math.cos(phaseAngle) * edge;
            shadow.lineTo(center + (float) terminatorX * radius, center + (float) y * radius);
        }
        shadow.close();

        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(Color.argb(224, 2, 3, 7));
        paint.setStyle(Paint.Style.FILL_AND_STROKE);
        paint.setStrokeWidth(radius * 0.021f);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setStrokeCap(Paint.Cap.ROUND);

        canvas.save();
        Path clip = new Path();
        clip.addCircle(center, center, radius, Path.Direction.CW);
        canvas.clipPath(clip);
        canvas.drawPath(shadow, paint);
        canvas.restore();
    }

    private static void drawRim(Canvas canvas, float center, float radius, double age) {
        double illumination = (1.0 - Math.cos((2.0 * Math.PI * age) / LunarPhase.SYNODIC_MONTH)) * 0.5;
        int[] dark = {132, 126, 208};
        int[] light = {224, 231, 205};
        int red = mix(dark[0], light[0], illumination);
        int green = mix(dark[1], light[1], illumination);
        int blue = mix(dark[2], light[2], illumination);

        Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        glow.setStyle(Paint.Style.STROKE);
        glow.setStrokeWidth(radius * 0.044f);
        glow.setColor(Color.argb((int) (255 * (0.08 + illumination * 0.07)), red, green, blue));
        canvas.drawCircle(center, center, radius - radius * 0.012f, glow);

        Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
        rim.setStyle(Paint.Style.STROKE);
        rim.setStrokeWidth(radius * 0.0116f);
        rim.setColor(Color.argb((int) (255 * (0.18 + illumination * 0.16)), red, green, blue));
        canvas.drawCircle(center, center, radius - radius * 0.012f, rim);
    }

    private static int mix(int from, int to, double amount) {
        return (int) Math.round(from + (to - from) * amount);
    }
}
