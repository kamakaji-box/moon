package jp.kamakaji.luna.widget;

/** The small, shared part of the LUNA phase calculation needed by the widget. */
final class LunarPhase {
    static final double SYNODIC_MONTH = 29.530588853;
    private static final long KNOWN_NEW_MOON = 947182440000L; // 2000-01-06T18:14:00Z

    private LunarPhase() {
    }

    static double age(long timeMillis) {
        double elapsedDays = (timeMillis - KNOWN_NEW_MOON) / 86400000.0;
        double remainder = elapsedDays % SYNODIC_MONTH;
        return remainder < 0 ? remainder + SYNODIC_MONTH : remainder;
    }
}
