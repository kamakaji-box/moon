package jp.kamakaji.luna.widget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.RemoteViews;

/** Thin bridge: show today's moon, then hand the user to the existing LUNA Web atlas. */
public class LunaWidgetProvider extends AppWidgetProvider {
    private static final int RENDER_SIZE_PX = 512;
    private static final String LUNA_WEB_URL = "https://kamakaji-box.github.io/moon/luna/";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateWidget(context, appWidgetManager, appWidgetId);
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        String action = intent.getAction();
        if (Intent.ACTION_DATE_CHANGED.equals(action)
                || Intent.ACTION_TIME_CHANGED.equals(action)
                || Intent.ACTION_TIMEZONE_CHANGED.equals(action)) {
            AppWidgetManager manager = AppWidgetManager.getInstance(context);
            ComponentName provider = new ComponentName(context, LunaWidgetProvider.class);
            onUpdate(context, manager, manager.getAppWidgetIds(provider));
        }
    }

    private static void updateWidget(Context context, AppWidgetManager manager, int appWidgetId) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.luna_widget);
        views.setImageViewBitmap(R.id.moon_image, MoonRenderer.render(context, RENDER_SIZE_PX));

        Intent openLuna = new Intent(Intent.ACTION_VIEW, Uri.parse(LUNA_WEB_URL));
        PendingIntent pendingIntent = PendingIntent.getActivity(
                context,
                appWidgetId,
                openLuna,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.luna_widget_root, pendingIntent);
        views.setOnClickPendingIntent(R.id.moon_image, pendingIntent);
        manager.updateAppWidget(appWidgetId, views);
    }
}
