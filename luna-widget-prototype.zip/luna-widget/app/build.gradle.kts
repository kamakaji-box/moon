plugins {
    id("com.android.application")
}

android {
    namespace = "jp.kamakaji.luna.widget"
    compileSdk = 35

    defaultConfig {
        applicationId = "jp.kamakaji.luna.widget"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
}
