# LUNA Androidホーム画面ウィジェット 試作

ホーム画面には、LUNA Webと同じNASA/LROCカラー地図を使った「今日の月」だけを表示します。

- 地名・数値・カード・ボタンなし
- 背景透明
- 月齢に合わせて月面を暗くする
- 新月付近は暗い月面をほんのり残す
- 月をタップすると既存のLUNA Webを開く
- 6時間ごとの更新＋日付・時刻・タイムゾーン変更時の更新

## GitHub ActionsでAPKを作る

このフォルダを独立したGitHubリポジトリへアップロードしてコミットすると、Actionsがdebug APKを作ります。

1. GitHubの `Actions` を開く
2. `Build LUNA Android widget` を選ぶ
3. `Run workflow` または push後の実行結果を開く
4. Artifactsから `luna-widget-debug-apk` をダウンロード
5. APKをAndroid端末へ入れてインストール
6. ホーム画面のウィジェット一覧から `LUNA` を配置

debug APKは個人用プロトタイプ向けです。公開配布やPlayストア公開は、後で署名設定を追加します。

## 技術メモ

ウィジェット側はWeb版を丸ごと移植せず、Javaで月齢計算と月画像の位相マスクだけを持ちます。月面地名DBやズーム・パンはWeb版に残します。
